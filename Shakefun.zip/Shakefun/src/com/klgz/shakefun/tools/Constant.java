/** 
 * 本程序代码版权归北京快乐格子信息技术有限公司或本项目委托的客户方所有。
 * Copyright www.kuailegezi.com  
 * legal@kuailegezi.com
 */
package com.klgz.shakefun.tools;

/**
 * @author wk
 *全局变量
 */
public class Constant {
	
	
	public static String cachefile="";
	
	
	public final static String OWN_BASICURL ="http://218.241.7.206:8087/";//本公司ip
	
//	public final static String KE_BASICURL ="http://125.208.12.71:8080/";//客户公网ip
//	public final static String KE_BASICURL ="http://125.208.12.71/";//客户公网ip
	public final static String KE_BASICURL ="http://app.yaolaiyaoqu.com/";//客户公网ip
	
	public final static String APP_ID_WEIXIN = "wxf42e5e9b3c63d792";
	
	public static String phoneID = "";
	
	/** 用户手机号 */
	public static String phonenu = "";
	/** 用户id */
	public static String userId = "";
	/** 用户密码 */
	public static String psw = "";
	/** token */
	public static String token ="";
	/**用户名 */
	public static String username ="";
	
	/** 链接头信息 */
//	public static final String base_url ="http://125.208.12.71:8080/appUser!request.action";
	
	
	/**用户是否登陆标志位  */
	public static boolean islogin = false;
	
	
	/**
	 * Dialog的加载内容
	 */
	public static final String Dialog_message_Jiazai = "正在加载中...";
	/*** 正在提交...*/
	public static final String Dialog_message_Tijiao = "正在提交...";
	

}
