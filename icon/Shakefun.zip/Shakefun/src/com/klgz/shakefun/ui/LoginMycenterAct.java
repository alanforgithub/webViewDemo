/** 
 * 本程序代码版权归北京快乐格子信息技术有限公司或本项目委托的客户方所有。
 * Copyright www.kuailegezi.com  
 * legal@kuailegezi.com
 */
package com.klgz.shakefun.ui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request.Method;
import com.android.volley.VolleyError;
import com.klgz.shakefun.bean.Registerbean;
import com.klgz.shakefun.bean.Status;
import com.klgz.shakefun.engine.PostResult;
import com.klgz.shakefun.enginemp.LoginEngine;
import com.klgz.shakefun.tools.Constant;
import com.klgz.shakefun.utils.CommonUtil;
import com.klgz.shakefun.utils.DialogUtils;
import com.klgz.shakefun.utils.LogUtil;
import com.klgz.shakefun.utils.net.ParamsUtils;
import com.klgz.ylyq.R;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

/**
 * @author wk 个人中心 登陆界面
 */
public class LoginMycenterAct extends BasicActivity {

	/** 用户名,密码 */
	private EditText login_username, login_password;
	/** 登陆 */
	private Button login_btn_login;
	/** 忘记密码 去注册 */
	private TextView login_forgotpsw, login_goregister;
	private String mobile, psw;
	/**
	 * 登录接口
	 */
	private String loginUrl = Constant.KE_BASICURL + "appUser!request.action";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_mycenter);
		getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		initView();
		initSetlistener();

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.backbtn:
			finish();
			break;
		case R.id.login_btn_login:// 登陆按钮
			toLogin();
			// login();
			break;
		case R.id.login_forgotpsw:// 忘记密码
			Intent forIntent = new Intent(LoginMycenterAct.this,
					ForgotPsw.class);
			startActivity(forIntent);
			finish();

			break;
		case R.id.login_goregister:// 去注册
			Intent intent = new Intent(LoginMycenterAct.this, Register.class);
			startActivity(intent);
			finish();
			break;
		default:
			break;
		}

	}

	@Override
	public void initView() {
		login_username = (EditText) findViewById(R.id.login_username);
		login_password = (EditText) findViewById(R.id.login_password);
		login_btn_login = (Button) findViewById(R.id.login_btn_login);
		login_forgotpsw = (TextView) findViewById(R.id.login_forgotpsw);
		login_goregister = (TextView) findViewById(R.id.login_goregister);
		findViewById(R.id.backbtn).setOnClickListener(this);

	}

	@Override
	public void initSetlistener() {
		login_btn_login.setOnClickListener(this);
		login_forgotpsw.setOnClickListener(this);
		login_goregister.setOnClickListener(this);

	}

	/**
	 * 登陆请求
	 */
	private void toLogin() {
		mobile = login_username.getText().toString().trim();
		psw = login_password.getText().toString().trim();
		Constant.phonenu = mobile;
		Constant.psw = psw;

		if (TextUtils.isEmpty(mobile)) {
			CommonUtil.custoast(LoginMycenterAct.this,
					getString(R.string.input_phone_number));
			return;
		}

		if (TextUtils.isEmpty(psw)) {
			CommonUtil.custoast(getApplicationContext(),
					getString(R.string.input_pwd));
			return;
		}

		DialogUtils.showProgressDialog(this, Constant.Dialog_message_Jiazai);
		DialogUtils.dialog.setMessage(getString(R.string.login_ing));

		Map<String, String> maps = new HashMap<String, String>();
		maps.put("data", ParamsUtils.getLoginParams(mobile, psw));

		LoginEngine engine = new LoginEngine(getApplicationContext());
		engine.setPostResult(new PostResult<Registerbean>() {

			@Override
			public void getResult(Status status, List<Registerbean> datas) {
				if (status.getCode() == 200) {
					Registerbean userInfo = datas.get(0);

					DialogUtils.closeProgressDialog();

					Constant.userId = userInfo.getId();
					Constant.token = userInfo.getToken();
					Constant.islogin = true;
					Constant.username = userInfo.getName();

					Intent intent = new Intent(LoginMycenterAct.this,
							LogingedCenter.class);
					startActivity(intent);
					finish();

				} else {
					Toast.makeText(getApplicationContext(), status.getMsg(),
							Toast.LENGTH_SHORT).show();
					DialogUtils.closeProgressDialog();
				}

			}

			@Override
			public void onError(VolleyError error) {
				DialogUtils.closeProgressDialog();
				Toast.makeText(getApplicationContext(), "网络出错",
						Toast.LENGTH_SHORT).show();
			}
		});
		engine.getData(loginUrl, maps, Method.POST);

	}

}
