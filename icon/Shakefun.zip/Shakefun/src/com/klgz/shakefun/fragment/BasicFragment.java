package com.klgz.shakefun.fragment;

import android.support.v4.app.Fragment;
import android.view.View;
import android.view.View.OnClickListener;



/**
 * fragment基类
 * @author wk
 *
 */

public abstract class BasicFragment extends Fragment implements OnClickListener{

	
	/**
	 * 初始化view对象
	 */
	 abstract void initView(View view);

	/**
	 * 设置监听器
	 */
	abstract void setListener();

	
	
	
	
	
}
