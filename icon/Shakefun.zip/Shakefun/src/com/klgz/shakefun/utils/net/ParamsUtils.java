package com.klgz.shakefun.utils.net;

import org.json.JSONException;
import org.json.JSONObject;

import com.klgz.shakefun.tools.Constant;
import com.klgz.shakefun.utils.LogUtil;

/**
 * 此类用于封装请求服务器的参数类
 * 
 * @author guangbingw
 * 
 */
public class ParamsUtils {
	public static String getLoginParams(String mobile, String psw) {
		JSONObject params = new JSONObject();
		JSONObject data = new JSONObject();
		try {
			params.put("phone", mobile);
			params.put("password", psw);
			params.put("userToken", Constant.phoneID);

			data.put("method", "userLogin");
			data.put("userId", "");
			data.put("token", "");
			data.putOpt("params", params);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		LogUtil.i("login params = " + data.toString());

		return data.toString();

	}
}
